import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

# 1. Load CSV dataset
data = pd.read_csv("dataset.csv")

print("Dataset:")
print(data.head())

# 2. Separate input and output
X = data.iloc[:, :-1]
y = data.iloc[:, -1]

# 3. Split dataset into training and testing
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    random_state=42
)

# 4. Standardize the input data
scaler = StandardScaler()

X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# 5. Create Neural Network
model = Sequential()

model.add(Dense(16, activation="relu", input_shape=(X_train.shape[1],)))
model.add(Dense(8, activation="relu"))
model.add(Dense(1, activation="sigmoid"))

# 6. Compile the model
model.compile(
    optimizer="adam",
    loss="binary_crossentropy",
    metrics=["accuracy"]
)

# 7. Train the model
model.fit(
    X_train,
    y_train,
    epochs=10,
    batch_size=10,
    verbose=1
)

# 8. Evaluate the model
loss, accuracy = model.evaluate(X_test, y_test)

print("\nTest Loss:", loss)
print("Test Accuracy:", accuracy)

# 9. Make predictions
predictions = model.predict(X_test)

predicted_classes = (predictions > 0.5).astype(int)

print("\nPredicted values:")
print(predicted_classes.flatten())

print("\nActual values:")
print(y_test.to_numpy())